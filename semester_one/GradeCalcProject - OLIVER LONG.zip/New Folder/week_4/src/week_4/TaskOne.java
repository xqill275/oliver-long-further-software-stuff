/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week_4;

/**
 *
 * @author olive
 */
public class TaskOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        bankInOneFile bank = new bankInOneFile("oliver", "1", 0);
        bank.main(args);
    }
}

