/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week_4;

/**
 *
 * @author olive
 */
public class TaskTwo {
    public static void main(String[] args) {
        bankVersionTwoMainClass bank = new bankVersionTwoMainClass("oliver", "1", 0);
        bank.main(args);
    }    
}
